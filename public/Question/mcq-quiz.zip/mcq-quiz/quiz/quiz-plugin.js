(function($){
  $.fn.mcqQuiz = function(options) {
    const settings = $.extend({ questions: [] }, options);

    return this.each(function(){
      const container = $(this).empty();

      settings.questions.forEach((q, index) => {
        let optionsHTML = '';
        q.options.forEach((opt, i) => {
          optionsHTML += `<button class="quiz-button" data-index="${i}">${opt}</button>`;
        });

        const questionBox = $(`
          <div class="question-box" data-index="${index}">
            <div class="question">${q.question}</div>
            <div class="button-container">${optionsHTML}</div>
            <div class="feedback"></div>
          </div>
        `);
        container.append(questionBox);
      });

      container.on('click', '.quiz-button', function(){
        const btn = $(this);
        const parent = btn.closest('.question-box');
        const qIndex = parent.data('index');
        const selected = parseInt(btn.data('index'));
        const correct = settings.questions[qIndex].answer;
        const feedback = parent.find('.feedback');

        if (selected === correct) {
          feedback.text('✅ Chính xác!').removeClass('incorrect').addClass('correct');
        } else {
          feedback.text('❌ Sai rồi!').removeClass('correct').addClass('incorrect');
        }

        parent.find('.quiz-button').prop('disabled', true).css('opacity', 0.6);
      });
    });
  };
})(jQuery);
