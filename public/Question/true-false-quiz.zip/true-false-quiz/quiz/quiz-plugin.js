(function($){
  $.fn.trueFalseQuiz = function(options) {
    const settings = $.extend({ questions: [] }, options);

    return this.each(function(){
      const container = $(this).empty();

      settings.questions.forEach((q, index) => {
        let questionHTML = '';
        if (q.type === 'image') {
          questionHTML = '<img src="' + q.question + '" alt="Question Image" class="question-img"/>';
        } else {
          questionHTML = '<div class="question">' + q.question + '</div>';
        }

        const questionBox = $(`
          <div class="question-box" data-index="${index}">
            ${questionHTML}
            <div class="button-container">
              <button class="quiz-button" data-answer="true">Đúng</button>
              <button class="quiz-button" data-answer="false">Sai</button>
            </div>
            <div class="feedback"></div>
          </div>
        `);
        container.append(questionBox);
      });

      container.on('click', '.quiz-button', function(){
        const btn = $(this);
        const parent = btn.closest('.question-box');
        const index = parent.data('index');
        const userAnswer = btn.data('answer') === "true";
        const correctAnswer = settings.questions[index].answer;
        const feedback = parent.find('.feedback');

        if (userAnswer === correctAnswer) {
          feedback.text('✅ Chính xác!').removeClass('incorrect').addClass('correct');
        } else {
          feedback.text('❌ Sai rồi!').removeClass('correct').addClass('incorrect');
        }

        parent.find('.quiz-button').prop('disabled', true).css('opacity', 0.5);
      });
    });
  };
})(jQuery);
